﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Fields_PlayFab : MonoBehaviour {
	public InputField User;
	public InputField Password;
	public Button Login;
	
	// Use this for initialization
	void Start () {
		Login.onClick.AddListener(() => LogIn());
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	public void LogIn()
	{
		PlayFabLoginCalls.RequestSpinner();
		if(User.text.Contains("@"))
		{
			if(PlayFabLoginCalls.ValidateEmail(User.text))
			{
				PlayFabLoginCalls.LoginWithEmail(User.text, Password.text);
			}
		}
		else
		{
			PlayFabLoginCalls.LoginWithUsername(User.text, Password.text);
		}
	}
}
