﻿using UnityEngine;
using System.Runtime.InteropServices;

public class CBGNotificationServices {
	
	#if UNITY_IOS
	[DllImport ("__Internal")]
	private static extern void CBG_RegisterForRemoteNotifications(int types);
	
	public static void RegisterForRemoteNotificationsTypes(RemoteNotificationType types) {
		if (!Application.isEditor) {
			string sysInfo = SystemInfo.operatingSystem;
			sysInfo = sysInfo.Replace("iPhone OS ", "");
			string[] chunks = sysInfo.Split('.');
			int majorVersion = int.Parse(chunks[0]);
			if (majorVersion >= 8)
				CBG_RegisterForRemoteNotifications((int) types);
			else
				//NotificationServices.RegisterForRemoteNotificationsTypes(types);
				NotificationServices.RegisterForRemoteNotificationTypes(types);
		}
	}
	#endif
	
}