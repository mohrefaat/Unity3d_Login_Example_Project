﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using PlayFab.Serialization.JsonFx;

public class AuthenticationController : MonoBehaviour {
	public string PlayFabTitleId = string.Empty;
	public BottomMenuController bottomMenu;
	public DebugInfoController debugInfo;
	public AutoLoginController autoLogin;
	public RegisterController registerLogin;
	public ManualController manualLogin;

	public enum LoginStates { Manual = 0, Register = 1, Auto = 2, LoggedIn = 3 }
	public LoginStates activeState = LoginStates.Manual;
	private LoginStates previousFrameState;
	
	//public bool isCountingDown = false; 
	public delegate void OnLoginStateChange(LoginStates state);
	public static event OnLoginStateChange LoginStateChange;
	
	void OnEnable()
	{
		PlayFabLoginCalls.OnLoginFail += HandleOnLoginFail;
		PlayFabLoginCalls.OnLoginSuccess += HandleOnLoginSuccess;
		PlayFabLoginCalls.OnPlayfabCallbackSuccess += HandleCallbackSuccess;
		PlayFabLoginCalls.OnPlayFabError += HandlePlayFabError;
	}
	
	void OnDisable()
	{
		PlayFabLoginCalls.OnLoginFail -= HandleOnLoginFail;
		PlayFabLoginCalls.OnLoginSuccess -= HandleOnLoginSuccess;
		PlayFabLoginCalls.OnPlayfabCallbackSuccess -= HandleCallbackSuccess;
		PlayFabLoginCalls.OnPlayFabError -= HandlePlayFabError;
	}
	
	
	// Use this for initialization
	void Start () 
	{
		if(!string.IsNullOrEmpty(this.PlayFabTitleId) && string.IsNullOrEmpty(PlayFab.PlayFabSettings.TitleId))
		{
			PlayFab.PlayFabSettings.TitleId = this.PlayFabTitleId;
			this.activeState = LoginStates.Auto;
		}
		else if(string.IsNullOrEmpty(PlayFab.PlayFabSettings.TitleId))
		{
			Debug.Log ("PlayFab Title Id Required. Please enter your Id on the Authentication Controller");
		}
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(this.activeState != this.previousFrameState)
		{
			ChangeState(this.activeState);
		}
	}

	public void ChangeState(LoginStates state)
	{
		Debug.Log(string.Format("Changing State to: {0}", state.ToString()));
		switch(state)
		{
			case LoginStates.Manual:
				manualLogin.EnableUI();
				autoLogin.DisableUI();
				registerLogin.DisableUI();
			break;
			
			case LoginStates.Register:
				manualLogin.DisableUI();
				autoLogin.DisableUI();
				registerLogin.EnableUI();
			break;
			
			case LoginStates.Auto:
				manualLogin.DisableUI();
				autoLogin.EnableUI();
				registerLogin.DisableUI();
			break;
			
			case LoginStates.LoggedIn:
				manualLogin.DisableUI();
				autoLogin.DisableUI();
				registerLogin.DisableUI();
				bottomMenu.DisableUI();
				this.GetComponent<Image>().enabled = false;
			break;
		}
		
		this.previousFrameState = this.activeState;
		
		if(LoginStateChange != null)
			LoginStateChange(state);
		
	}
	
	
	void HandlePlayFabError(string message, PlayFabAPIMethods method)
	{
		
	}
	
	void HandleCallbackSuccess(string message, PlayFabAPIMethods method)
	{
		if(method == PlayFabAPIMethods.GetAccountInfo)
		{
			SaveUserAccountInfo();
		}
	}
	
	
	void HandleOnLoginSuccess(string message)
	{
		SaveLoginPathway();
		PlayFabLoginCalls.RequestSpinner();
		PlayFabLoginCalls.GetAccountInfo();	
		this.activeState = LoginStates.LoggedIn;
	}
	
	void HandleOnLoginFail(string message)
	{
		if(message == "Logout")
		{
			this.GetComponent<Image>().enabled = true;
			bottomMenu.EnableUI();
		}
		this.activeState = LoginStates.Manual;
	}
	
	
	void SaveUserAccountInfo()
	{
		string serialized = JsonWriter.Serialize(PlayFabLoginCalls.LoggedInUserInfo);
		//Debug.Log(serialized);
		PlayerPrefs.SetString("accountInfo", serialized);
	}
	void SaveLoginPathway()
	{
		
		PlayerPrefs.SetString("loginMethodUsed", PlayFabLoginCalls.LoginMethodUsed.ToString());
		PlayerPrefs.SetString("authTicket", PlayFab.PlayFabClientAPI.AuthKey);
		
		Debug.Log("PPrefs: " + PlayFabLoginCalls.LoginMethodUsed.ToString() + " : " + PlayFab.PlayFabClientAPI.AuthKey );
	}
}
