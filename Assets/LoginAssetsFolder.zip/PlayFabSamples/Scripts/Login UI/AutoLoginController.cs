﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;

using PlayFab.Serialization.JsonFx;
using PlayFab.ClientModels;

public class AutoLoginController : MonoBehaviour {
	//public bool isCountingDown = false; 
	
	public Text status;
	public Text details;
	public Text counter;
	public Text instructions;
	public InputField password;
	public Button login;
	public Button rock_it;
	public Transform passwordPrompt;
	public Transform countdown;
	
	public bool isCounting;
	
	
	public float autoLoginAfter = 6.0f; // in seconds
	// autologin timer variables
	private float timeToStart = 0;
	private float timeToFinish = 0;
	private bool createNewAccount = true;
	private UserAccountInfo accountInfo;
	private PlayFabLoginCalls.LoginPathways loginPathToUse;	
	private bool? wasPreviousAuthTicketValid = null;
	
	void OnEnable()
	{
		//PlayFabLoginCalls.OnLoginFail += HandleOnLoginFail;
		//PlayFabLoginCalls.OnLoginSuccess += HandleOnLoginSuccess;
		PlayFabLoginCalls.OnPlayfabCallbackSuccess += HandleCallbackSuccess;
		PlayFabLoginCalls.OnPlayFabError += HandlePlayFabError;
		
		timeToStart = 0;
		timeToFinish = 0;
		autoLoginAfter = 6.0f; // in seconds
		ReadLoginDataRecord();
	}
	
	void OnDisable()
	{
		//PlayFabLoginCalls.OnLoginFail -= HandleOnLoginFail;
		//PlayFabLoginCalls.OnLoginSuccess -= HandleOnLoginSuccess;
		PlayFabLoginCalls.OnPlayfabCallbackSuccess -= HandleCallbackSuccess;
		PlayFabLoginCalls.OnPlayFabError -= HandlePlayFabError;
		this.isCounting = false;
	}
	
	
	void HandlePlayFabError(string message, PlayFabAPIMethods method)
	{
		if(message.Contains("invalid ticket") && method == PlayFabAPIMethods.GetAccountInfo)
		{
			this.wasPreviousAuthTicketValid = false;
			PlayerPrefs.DeleteKey("authTicket");
			ReadLoginDataRecord();
		}
	}
	
	void HandleCallbackSuccess(string message, PlayFabAPIMethods method)
	{
		if(message.Contains("Valid") && method == PlayFabAPIMethods.GetAccountInfo)
		{
			this.wasPreviousAuthTicketValid = true;
			this.accountInfo = PlayFabLoginCalls.LoggedInUserInfo;
			
			EnableCountdown();
			this.createNewAccount = false;
			this.status.text = "Found a valid ticket...";
			string displayName = string.IsNullOrEmpty(this.accountInfo.Username) ? this.accountInfo.PlayFabId : this.accountInfo.Username;
			
			this.details.text = string.Format("Using: {0}, click below to manually change accounts", displayName);
			this.loginPathToUse = PlayFabLoginCalls.LoginPathways.gameCenter;
		}
	}
	
	void CheckPreviousAuthTicket(string ticket)
	{
		PlayFabLoginCalls.RequestSpinner();
		PlayFabLoginCalls.TestAuthTicket(ticket);
	}
	
	void ReadLoginDataRecord()
	{
		this.status.text = "Finding previous logins...";
		if(PlayerPrefs.HasKey("authTicket"))
		{
			this.status.text = "Previous login found...";
			this.details.text = "Validating authentication ticket...";
			string ticket = PlayerPrefs.GetString("authTicket");
			CheckPreviousAuthTicket(ticket);
		}	
		else if(PlayerPrefs.HasKey("loginMethodUsed"))
		{
			this.status.text = "Previous login found...";
			
			string raw = PlayerPrefs.GetString("loginMethodUsed");
			PlayFabLoginCalls.LoginPathways method = (PlayFabLoginCalls.LoginPathways) Enum.Parse(typeof(PlayFabLoginCalls.LoginPathways), raw);
			switch(method)
			{
				case PlayFabLoginCalls.LoginPathways.pf_username:
					if(PlayerPrefs.HasKey("accountInfo"))
					{
						this.accountInfo = JsonReader.Deserialize<UserAccountInfo>(PlayerPrefs.GetString("accountInfo"));
						this.createNewAccount = false;
						PrompForPassword();
						this.details.text = string.Format("PlayFab Username: {0} found...", this.accountInfo.Username);
						this.instructions.text = "Enter password to continue, or change accounts manually by clicking below.";
						this.loginPathToUse = PlayFabLoginCalls.LoginPathways.pf_username;
					}
					break;
					
				case PlayFabLoginCalls.LoginPathways.pf_email:
					if(PlayerPrefs.HasKey("accountInfo"))
					{
						this.accountInfo = JsonReader.Deserialize<UserAccountInfo>(PlayerPrefs.GetString("accountInfo"));
						this.createNewAccount = false;
						PrompForPassword();
						this.details.text = string.Format("Email: {0} found...", this.accountInfo.PrivateInfo.Email);
						this.instructions.text = "Enter password to continue, or change accounts manually by clicking below.";
						this.loginPathToUse = PlayFabLoginCalls.LoginPathways.pf_email;
					}
					break;
					
				case PlayFabLoginCalls.LoginPathways.deviceId:
						EnableCountdown();
						this.createNewAccount = false;
						this.details.text = "Device Id, click below to manually change accounts";
						this.loginPathToUse = PlayFabLoginCalls.LoginPathways.deviceId;
					break;
					
				case PlayFabLoginCalls.LoginPathways.facebook:
						EnableCountdown();
						this.createNewAccount = false;
						this.details.text = "Facebook, click below to manually change accounts";
						this.loginPathToUse = PlayFabLoginCalls.LoginPathways.facebook;
					break;
					
				case PlayFabLoginCalls.LoginPathways.gameCenter:
						EnableCountdown();
						this.createNewAccount = false;
						this.details.text = "GameCenter, click below to manually change accounts";
						this.loginPathToUse = PlayFabLoginCalls.LoginPathways.gameCenter;
					break;
					
				case PlayFabLoginCalls.LoginPathways.googlePlus:
						EnableCountdown();
						this.createNewAccount = false;
						this.details.text = "Google+, click below to manually change accounts";
						this.loginPathToUse = PlayFabLoginCalls.LoginPathways.googlePlus;
					break;
					
				case PlayFabLoginCalls.LoginPathways.steam:
						EnableCountdown();
						this.createNewAccount = false;
						this.details.text = "Steam, click below to manually change accounts";
						this.loginPathToUse = PlayFabLoginCalls.LoginPathways.steam;
					break;
				default:
					AutoNewAccount();
				break;
			}
		}
		else
		{
			AutoNewAccount();
		}
		
	}
	

	// Use this for initialization
	void Start () 
	{
		login.onClick.AddListener(() => Login());
		rock_it.onClick.AddListener(() => Login());	
	}
	
	// Update is called once per frame
	void Update () 
	{
		// countdown bits
		if(this.isCounting)
		{
			if(this.timeToStart == 0)
			{
				this.timeToStart = Time.time;
				this.timeToFinish = this.timeToStart + autoLoginAfter;
			}
			
			if(Time.time < this.timeToFinish)
			{
				//GUIStyle countdownStyle = Mathf.Floor((this.timeToFinish - Time.time)) % 2 > 0 ? GUI.skin.GetStyle("autoLog_count_1") : GUI.skin.GetStyle("autoLog_count_2");
				string label = (this.timeToFinish - Time.time) >1  ? (this.timeToFinish - Time.time).ToString("F") : "Blast Off!";
				this.counter.text = label;
			}
			else
			{
				this.isCounting = false;
				Login();
			}
		}
	}
	
	void PrompForPassword()
	{
		this.isCounting = false;
		this.countdown.gameObject.SetActive(false);
		this.passwordPrompt.gameObject.SetActive(true);
	}
	
	void EnableCountdown()
	{
		this.passwordPrompt.gameObject.SetActive(false);
		this.countdown.gameObject.SetActive(true);
		this.isCounting = true;
	}
	
	void AutoNewAccount()
	{
		this.status.text = "No previous login found...";
		this.details.text = "Creating a new account using device Id...\nclick below to manually change accounts";
		this.createNewAccount = true;
		this.autoLoginAfter *= 1.5f;
		EnableCountdown();
		this.loginPathToUse = PlayFabLoginCalls.LoginPathways.deviceId;
	}
	
	void Login()
	{	
		PlayFabLoginCalls.RequestSpinner();
		Debug.Log("Login Path: " + this.loginPathToUse);
		
		if(this.wasPreviousAuthTicketValid == true)
		{
			PlayFabLoginCalls.UsePreviousAuthTicket();
		}
		else
		{
			switch(this.loginPathToUse)
			{
				case PlayFabLoginCalls.LoginPathways.pf_username:
					PlayFabLoginCalls.LoginWithUsername(this.accountInfo.Username, this.password.text);
					break;
				case PlayFabLoginCalls.LoginPathways.pf_email:
					PlayFabLoginCalls.LoginWithEmail(this.accountInfo.PrivateInfo.Email, this.password.text);
					break;
				case PlayFabLoginCalls.LoginPathways.deviceId:
					PlayFabLoginCalls.LoginWithDeviceId(this.createNewAccount);
					break;
				case PlayFabLoginCalls.LoginPathways.facebook:
					PlayFabLoginCalls.StartFacebookLogin();
					break;
				case PlayFabLoginCalls.LoginPathways.gameCenter:
					PlayFabLoginCalls.StartGameCenterLogin();
					break;
				case PlayFabLoginCalls.LoginPathways.googlePlus:
					//PlayFabLoginCalls.LoginWithUsername(this.accountInfo.Username, this.password.text);
					break;
				case PlayFabLoginCalls.LoginPathways.steam:
					//PlayFabLoginCalls.LoginWithUsername(this.accountInfo.Username, this.password.text);
					break;
			}
		}
	}
	
	public void EnableUI()
	{
		this.gameObject.SetActive(true);
	}
	
	public void DisableUI()
	{
		this.gameObject.SetActive(false);
	}
	
}
