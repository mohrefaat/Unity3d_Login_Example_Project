﻿using UnityEngine;
using System.Collections;

public class TEST_PlayerPrefs : MonoBehaviour {
	public string authTicket = "C4B1CEE856CF3F54-0-0-9D68-8D21F384E701B7E-17F0B99202C37DBE.49D6ADAB313844AC";
	public PlayFabLoginCalls.LoginPathways pathway;
	public string accountInfo = "{\"PlayFabId\":\"C4B1CEE856CF3F54\",\"Created\":\"2014-08-19T00:40:18Z\",\"Username\":\"sdktestuser1\",\"TitleInfo\":{\"DisplayName\":\"SDKTesting1\",\"Origination\":null,\"Created\":\"2015-01-25T02:41:17Z\",\"LastLogin\":\"2015-03-12T20:50:36Z\",\"FirstLogin\":\"2015-01-25T02:41:17Z\",\"isBanned\":null},\"PrivateInfo\":{\"Email\":\"sdktestuser1@playfabsandbox.com\"},\"FacebookInfo\":null,\"SteamInfo\":null,\"GameCenterInfo\":null}";
	public bool clearPrefsOnAwake = false;
	public bool loadTestAuthTicket = false;
	public bool loadTestPathway = false;
	public bool loadTestAccountInfo = false;
	
	// expired session: C4B1CEE856CF3F54-0-0-98FA-8D21F384E701B7E-17F0B99202C37DBE.49D6ADAB313844AC
	// active session for SDKTestUser1: C4B1CEE856CF3F54-0-0-9D68-8D22B1BD1E4CB7E-90B179FFDC55C461.AF17E44FCC52D49B

	void Awake()
	{
		if(clearPrefsOnAwake == true)
		{
			PlayerPrefs.DeleteAll();
		}
		
		if(loadTestAuthTicket == true)
		{
			PlayerPrefs.SetString("authTicket", authTicket);

		}
		
		if(loadTestPathway == true)
		{
			PlayerPrefs.SetString("loginMethodUsed", pathway.ToString());
		}
		
		if(loadTestAccountInfo == true)
		{
			PlayerPrefs.SetString("accountInfo", accountInfo);
		}
	}
	
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
