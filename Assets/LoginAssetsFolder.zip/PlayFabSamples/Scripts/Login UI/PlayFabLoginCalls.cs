﻿using UnityEngine;
using UnityEngine.SocialPlatforms.GameCenter;
using System.Collections;
using System.Text.RegularExpressions;

using PlayFab;
using PlayFab.ClientModels;
using PlayFab.Internal;
using PlayFab.Serialization.JsonFx;



public class PlayFabLoginCalls  {
		
	public enum LoginPathways {deviceId = 1, pf_username = 2, facebook = 3, gameCenter = 4, pf_email = 5, steam = 6, googlePlus = 7  } 
	public static LoginPathways LoginMethodUsed;
	
	public static UserAccountInfo LoggedInUserInfo;
	public bool hasTitleId = false;
		
	public delegate void SuccessfulLoginHandler(string path);
	public static event SuccessfulLoginHandler OnLoginSuccess;
	
	public delegate void FailedLoginHandler(string message);
	public static event FailedLoginHandler OnLoginFail;
	
	public delegate void PlayFabErrorHandler(string message, PlayFabAPIMethods method);
	public static event PlayFabErrorHandler OnPlayFabError;
	
	public delegate void CallbackSuccess(string message, PlayFabAPIMethods method);
	public static event CallbackSuccess OnPlayfabCallbackSuccess;

	public delegate void StartSpinner();
	public static event StartSpinner StartSpinnerRequest;

	private const string emailPattern = @"^([0-9a-zA-Z]([\+\-_\.][0-9a-zA-Z]+)*)+@(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]*\.)+[a-zA-Z0-9]{2,17})$";
	private static string android_id = string.Empty; // device ID to use with playfab login
	private static string ios_id = string.Empty; // device ID to use with playfab login

	#region Access & Helper Functions
	public static void StartFacebookLogin()
	{
		if(FB.IsInitialized == true)
		{
			OnInitComplete();
		}
		else
		{
			FB.Init(OnInitComplete, OnHideUnity);
		}
	}
	
	public static void StartGameCenterLogin()
	{
		Debug.Log(Social.Active.ToString());
		Social.localUser.Authenticate(success => {
			if (success) {
				Debug.Log ("Authentication successful");
				LoginWithGamecenter(Social.localUser.id);
			}
			else
				Debug.Log ("Authentication failed");
		});
	}
	
	
	/// <summary>
	/// Validates the email.
	/// </summary>
	/// <returns><c>true</c>, if email was validated, <c>false</c> otherwise.</returns>
	/// <param name="em">Email address</param>
	public static bool ValidateEmail(string em){
		return Regex.IsMatch(em, PlayFabLoginCalls.emailPattern);
	}
	
	/// <summary>
	/// Validates the password.
	/// </summary>
	/// <returns><c>true</c>, if password was validated, <c>false</c> otherwise.</returns>
	/// <param name="p1">P1, text from password field one</param>
	/// <param name="p2">P2, text from password field two</param>
	public static bool ValidatePassword(string p1, string p2){
		return ((p1 == p2) && p1.Length > 5); 
	}
	
	public static void RequestSpinner()
	{
		if(StartSpinnerRequest != null)
			StartSpinnerRequest();
	}
	
	public static void UsePreviousAuthTicket()
	{
		if(OnLoginSuccess != null)
		{
			OnLoginSuccess(string.Format("{0}", LoggedInUserInfo.PlayFabId));
		}
	}
	#endregion
	
	
	//public static void Start


	#region playfab calls
		private static void LoginWithFacebook(string token)
		{
			LoginMethodUsed = LoginPathways.facebook;
			LoginWithFacebookRequest request = new LoginWithFacebookRequest();
			request.AccessToken = token;
			request.TitleId = PlayFabSettings.TitleId;
			request.CreateAccount = true;
			PlayFabClientAPI.LoginWithFacebook(request, OnLoginResult, OnLoginError);
		}
		
		private static void LoginWithGamecenter(string token)
		{
			LoginMethodUsed = LoginPathways.gameCenter;
			LoginWithGameCenterRequest request = new LoginWithGameCenterRequest();
			request.PlayerId = token;
			request.TitleId = PlayFabSettings.TitleId;
			request.CreateAccount = false;
			
			PlayFabClientAPI.LoginWithGameCenter(request, OnLoginResult, OnLoginError);
		}
		
		/// <summary>
		/// Registers the new playfab account.
		/// </summary>
		public static void RegisterNewPlayfabAccount(string user, string pass1, string pass2, string email )
		{
			if(user.Length == 0 || pass1.Length == 0 || pass2.Length ==0 || email.Length == 0)
			{
				OnPlayFabError("All fields are required.", PlayFabAPIMethods.RegisterPlayFabUser);
				return;
			}
			
			bool passwordCheck = ValidatePassword(pass1, pass2);
			bool emailCheck = ValidateEmail(email);
			
			if(!passwordCheck)
			{
				if(OnPlayFabError != null)
				{
					OnPlayFabError("Passwords must match and be longer than 5 characters.", PlayFabAPIMethods.RegisterPlayFabUser);
				}
				return;
				
			}
			else if(!emailCheck)
			{
				if(OnPlayFabError != null)
				{
					OnPlayFabError("Invalid Email format.", PlayFabAPIMethods.RegisterPlayFabUser);
				}
				return;
			}
			else
			{
				RegisterPlayFabUserRequest request = new RegisterPlayFabUserRequest();
				request.TitleId = PlayFabSettings.TitleId;
				request.Username = user;
				request.Email = email;
				request.Password = pass1;
				
				PlayFabClientAPI.RegisterPlayFabUser(request, OnRegisterResult, OnPlayFabCallbackError);
			}
		}
	
	/// <summary>
	/// Logins the with playfab.
	/// </summary>
	/// <param name="user">Username to use</param>
	/// <param name="pass">Password to use</param>
	public static void LoginWithUsername(string user, string password)
	{			
		if(user.Length>0 && password.Length>0)
		{
			LoginMethodUsed = LoginPathways.pf_username;
			LoginWithPlayFabRequest request = new LoginWithPlayFabRequest();
			request.Username = user;
			request.Password = password;
			request.TitleId = PlayFabSettings.TitleId;
			
			PlayFabClientAPI.LoginWithPlayFab(request, OnLoginResult, OnLoginError);
		}
		else
		{
			if(OnPlayFabError != null)
			{
				OnLoginFail("User Name and Password cannot be blank.");
			}
		}
	}
	
	public static void LoginWithEmail(string user, string password)
	{
		//PlayerPrefs.SetString("lastLoginPath","playfabEmail");
		
		if(user.Length>0 && password.Length>0 && ValidateEmail(user))
		{
			LoginMethodUsed = LoginPathways.pf_email;
			LoginWithEmailAddressRequest request = new LoginWithEmailAddressRequest();
			request.Email = user;
			request.Password = password;
			request.TitleId = PlayFabSettings.TitleId;
			
			PlayFabClientAPI.LoginWithEmailAddress(request, OnLoginResult, OnLoginError);
			
		}
		else
		{
			if(OnPlayFabError != null)
			{
				OnLoginFail("User / Password inputs error. Check credentails and try again");
			}
		}
		
	}
	
	
	/// <summary>
	/// Logins the with device identifier.
	/// </summary>
	public static void LoginWithDeviceId( bool createAcount)
	{
		if(Application.platform != RuntimePlatform.Android && Application.platform != RuntimePlatform.IPhonePlayer)
		{
			if(OnLoginFail != null)
			{
				OnLoginFail("Must be using android or ios platforms to use deveice id.");
			}
			return;
		}
		
		#if UNITY_ANDROID
		//http://answers.unity3d.com/questions/430630/how-can-i-get-android-id-.html
		AndroidJavaClass clsUnity = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
		AndroidJavaObject objActivity = clsUnity.GetStatic<AndroidJavaObject>("currentActivity");
		AndroidJavaObject objResolver = objActivity.Call<AndroidJavaObject>("getContentResolver");
		AndroidJavaClass clsSecure = new AndroidJavaClass("android.provider.Settings$Secure");
		android_id = clsSecure.CallStatic<string>("getString", objResolver, "android_id");
		#endif
		
		#if UNITY_IPHONE
		ios_id = iPhone.vendorIdentifier;
		#endif
		
		
		if(string.IsNullOrEmpty(ios_id) && string.IsNullOrEmpty(android_id))
		{
			// not possible to device Id
			if(OnLoginFail != null)
			{
				OnLoginFail("Must be using android or ios platforms to use deveice id.");
			}
		}
		else
		{
			LoginMethodUsed = LoginPathways.deviceId;
			if(!string.IsNullOrEmpty(android_id))
			{
				Debug.Log("Using Android Device ID: " + android_id);
				LoginWithAndroidDeviceIDRequest request = new LoginWithAndroidDeviceIDRequest();
				request.AndroidDeviceId = android_id;
				request.TitleId = PlayFabSettings.TitleId;
				request.CreateAccount = createAcount;
				PlayFabClientAPI.LoginWithAndroidDeviceID(request, OnLoginResult, OnLoginError);
			}
			else if (!string.IsNullOrEmpty(ios_id))
			{
				Debug.Log("Using IOS Device ID: " + ios_id);
				LoginWithIOSDeviceIDRequest request = new LoginWithIOSDeviceIDRequest();
				request.DeviceId = ios_id;
				request.TitleId = PlayFabSettings.TitleId;
				request.CreateAccount = createAcount;
				PlayFabClientAPI.LoginWithIOSDeviceID(request, OnLoginResult, OnLoginError);
			}
		}
	}
	
	/// <summary>
	/// Calls the UpdateUserTitleDisplayName request API
	/// </summary>
	public static void UpdateDisplayName()
	{
//		if(this.displayName == this.displayNameInput)
//		{
//			Debug.Log ("Name remains the same, moving on!");
//		}
//		else if(this.displayNameInput.Length > 2 && this.displayNameInput.Length < 26)
//		{ 
//			this.nameStatus = this.spinner;
//			UpdateUserTitleDisplayNameRequest request = new UpdateUserTitleDisplayNameRequest();
//			request.DisplayName = this.displayNameInput;
//			PlayFabClientAPI.UpdateUserTitleDisplayName(request, OnUpdateDisplayNameSuccess, OnPlayFabCallbackError);
//		}
//		else
//		{
//			this.errorMessage = "Display name must be between 3 and 25 characters";
//		}
	}
	
	/// <summary>
	/// Gets the user account info
	/// </summary>
	public static void TestAuthTicket(string ticket)
	{
		if(!string.IsNullOrEmpty(ticket))
		{
			//Debug.Log(ticket);
			PlayFabClientAPI.AuthKey = ticket;
			GetAccountInfoRequest request = new GetAccountInfoRequest();
			PlayFabClientAPI.GetAccountInfo(request, OnTestAuthTicketSuccess, OnTestAuthTicketError);
		}
		else
		{
			if(OnPlayFabError != null)
			{
				OnPlayFabError("invalid ticket", PlayFabAPIMethods.GetAccountInfo);
			}
		}
	}
	
	public static void GetAccountInfo()
	{
		GetAccountInfoRequest request = new GetAccountInfoRequest();
		PlayFabClientAPI.GetAccountInfo(request, OnGetAccountInfoSucces, OnPlayFabCallbackError);
	}
	
	
	/// <summary>
	/// Logs the user out.
	/// </summary>
	public static void Logout()
	{
		OnLoginFail("Logout");
		if(FB.IsInitialized == true && FB.IsLoggedIn == true)
		{
			CallFBLogout();
		}
	}
	#endregion
	
	
	#region playfab callbacks

		private static void OnPlayFabCallbackError(PlayFabError error)
		{
			string errorMessage = string.Empty;

			if(OnPlayFabError != null)
			{
				OnPlayFabError(errorMessage, PlayFabAPIMethods.Generic);
			}
		}
		
		
		static void OnGetAccountInfoSucces( GetAccountInfoResult result)
		{
			PlayFabLoginCalls.LoggedInUserInfo = result.AccountInfo;
			if(OnPlayfabCallbackSuccess != null)
			{
				OnPlayfabCallbackSuccess("", PlayFabAPIMethods.GetAccountInfo);	
			}
		}
		
		
		/// <summary>
		/// Called after a successful account info request
		/// </summary>
		/// <param name="result">Result.</param>
		static void OnTestAuthTicketSuccess(GetAccountInfoResult result) // GetUserCombinedInfoResult
		{
			PlayFabLoginCalls.LoggedInUserInfo = result.AccountInfo;
			if(OnPlayfabCallbackSuccess != null)
			{
				OnPlayfabCallbackSuccess("Valid", PlayFabAPIMethods.GetAccountInfo);	
			}	
		}	
			
		static void OnTestAuthTicketError(PlayFabError error)
		{
			if(OnPlayFabError != null)
			{
				OnPlayFabError(error.ErrorMessage, PlayFabAPIMethods.GetAccountInfo);
			}
		}
	
		/// <summary>
		/// Called on a successful loging result
		/// </summary>
		/// <param name="result">Result object returned from the PlayFab server</param>
		private static void OnRegisterResult(RegisterPlayFabUserResult result){
			if(OnPlayfabCallbackSuccess != null)
			{
				OnPlayfabCallbackSuccess("Registration Successful!", PlayFabAPIMethods.RegisterPlayFabUser);
			}
		}
		
		/// <summary>
		/// Called on a successful login attempt
		/// </summary>
		/// <param name="result">Result object returned from PlayFab server</param>
		private static void OnLoginResult(LoginResult result)
		{
			
			if(OnLoginSuccess != null)
			{
				OnLoginSuccess(string.Format("{0}", result.PlayFabId ));
			}
		}
		
		/// <summary>
		/// Raises the login error event.
		/// </summary>
		/// <param name="error">Error.</param>
		private static void OnLoginError(PlayFabError error)
		{
			string errorMessage = string.Empty;
			if (error.Error == PlayFabErrorCode.InvalidParams && error.ErrorDetails.ContainsKey("Password"))
			{
				errorMessage = "Invalid Password";
			}
			else if (error.Error == PlayFabErrorCode.InvalidParams && error.ErrorDetails.ContainsKey("Username") || (error.Error == PlayFabErrorCode.InvalidUsername))
			{
				errorMessage = "Invalid Username";
			}
			else if (error.Error == PlayFabErrorCode.AccountNotFound)
			{
				errorMessage = "Account Not Found";
			}
			else if (error.Error == PlayFabErrorCode.AccountBanned)
			{
				errorMessage = "Account Banned";
			}
			else if (error.Error == PlayFabErrorCode.InvalidUsernameOrPassword)
			{
				errorMessage = "Invalid Username or Password";
			}
			else
			{
				errorMessage = error.ErrorMessage;
			}
			
			if(OnLoginFail != null)
			{
				OnLoginFail(errorMessage);
			}
		}
	
		/// <summary>
		/// Called after a successful name update request
		/// </summary>
		/// <param name="result">Result.</param>
		private static void OnUpdateDisplayNameSuccess(UpdateUserTitleDisplayNameResult result)
		{
//			this.displayName = result.DisplayName;
//			this.displayNameInput = string.IsNullOrEmpty(result.DisplayName) ? "New Display Name" : result.DisplayName;
//			this.nameStatus = this.success;
		}
	#endregion
	
	
	/* FOLLOWING CODE FROM FACEBOOK SDK EXAMPLES*/
	#region fb_helperfunctions
	public static void OnInitComplete()
	{
		Debug.Log("FB.Init completed: Is user logged in? " + FB.IsLoggedIn);
		if(FB.IsLoggedIn == false)
		{
			CallFBLogin();
		}
		else
		{
			LoginWithFacebook(FB.AccessToken);
		}
		
		
	}
	
	public static void OnHideUnity(bool isGameShown)
	{
		Debug.Log("Is game showing? " + isGameShown);
	}
	
	private static void CallFBLogin()
	{
		FB.Login("public_profile,email,user_friends", LoginCallback);
	}
	
//	private static void CallFBLoginForPublish()
//	{
//		// It is generally good behavior to split asking for read and publish
//		// permissions rather than ask for them all at once.
//		//
//		// In your own game, consider postponing this call until the moment
//		// you actually need it.
//		FB.Login("publish_actions", LoginCallback);
//	}
	
	public static void LoginCallback(FBResult result)
	{
		string lastResponse = string.Empty;
		if (result.Error != null)
			lastResponse = "Error Response:\n" + result.Error;
		else if (!FB.IsLoggedIn)
		{
			lastResponse = "Login cancelled by Player";
		}
		else
		{
			lastResponse = "Login was successful!";
			
			//Debug.Log(FB.AccessToken);
			LoginWithFacebook(FB.AccessToken);
		}
	}
	
	private static void CallFBLogout()
	{
		FB.Logout();
	}
	
	#endregion	
}


#region API Enum
	public enum PlayFabAPIMethods { Generic, RegisterPlayFabUser, LoginWithPlayFab, GetAccountInfo} 
#endregion
